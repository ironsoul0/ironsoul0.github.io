const askToken = require("./askToken");
const askSecret = require("./askSecret");
const askFeedback = require("./askFeedback");

module.exports = [askToken, askSecret, askFeedback];
